using UnityEngine;

public class PlayerMovement : MonoBehaviour
{
    [Header("Movement Settings")]
    public float walkSpeed = 5f;
    public float runSpeed = 10f;
    public float maxSpeed = 12f;
    public float acceleration = 8f;
    public float deceleration = 10f;
    public float groundDrag = 5f;
    public float airMultiplier = 0.4f;

    [Header("Rotation Settings")]
    public float rotationSpeed = 200f;
    public float rotationSmoothing = 12f;

    [Header("Jump Settings")]
    public float jumpForce = 7f;
    public float jumpCooldown = 0.25f;
    public float airDrag = 1f;
    public LayerMask groundLayer;

    private Rigidbody rb;
    private float moveHorizontal;
    private float moveVertical;
    private bool readyToJump = true;
    private bool isGrounded;
    private float currentSpeed;
    private float desiredSpeed;
    private float speedDifference;
    private float movementMultiplier = 1f;

    void Start()
    {
        rb = GetComponent<Rigidbody>();
        rb.freezeRotation = true;
        currentSpeed = walkSpeed;
    }

    void Update()
    {
        GetInput();
        ControlSpeed();
        ControlDrag();
        HandleRotation();
    }

    void FixedUpdate()
    {
        MovePlayer();
    }

    private void GetInput()
    {
        moveHorizontal = Input.GetAxisRaw("Horizontal");
        moveVertical = Input.GetAxisRaw("Vertical");

        // ��� ��� ������� Shift
        desiredSpeed = Input.GetKey(KeyCode.LeftShift) ? runSpeed : walkSpeed;
        currentSpeed = Mathf.Lerp(currentSpeed, desiredSpeed, Time.deltaTime * 2f);

        // ������
        if (Input.GetKey(KeyCode.Space) && readyToJump && isGrounded)
        {
            readyToJump = false;
            Jump();
            Invoke(nameof(ResetJump), jumpCooldown);
        }
    }

    private void MovePlayer()
    {
        // �������� �����
        isGrounded = Physics.Raycast(transform.position, Vector3.down, 1.1f, groundLayer);
        movementMultiplier = isGrounded ? 1f : airMultiplier;

        // ������ ����������� ��������
        Vector3 moveDirection = transform.forward * moveVertical + transform.right * moveHorizontal;
        moveDirection.Normalize();

        // ������� ���������/����������
        speedDifference = currentSpeed - rb.linearVelocity.magnitude;
        float accelerationRate = (Mathf.Abs(moveVertical) > 0.1f || Mathf.Abs(moveHorizontal) > 0.1f)
            ? acceleration : deceleration;

        // ���������� ����
        rb.AddForce(moveDirection * speedDifference * accelerationRate * movementMultiplier, ForceMode.Acceleration);
    }

    private void ControlSpeed()
    {
        Vector3 flatVel = new Vector3(rb.linearVelocity.x, 0f, rb.linearVelocity.z);

        // ����������� ��������
        if (flatVel.magnitude > currentSpeed)
        {
            Vector3 limitedVel = flatVel.normalized * currentSpeed;
            rb.linearVelocity = new Vector3(limitedVel.x, rb.linearVelocity.y, limitedVel.z);
        }
    }

    private void ControlDrag()
    {
        rb.linearDamping = (isGrounded && (Mathf.Abs(moveVertical) < 0.1f && Mathf.Abs(moveHorizontal) < 0.1f))
            ? groundDrag : airDrag;
    }

    private void HandleRotation()
    {
        if (Input.GetMouseButton(1)) // ������� ������ ��� ������� ���
        {
            float mouseX = Input.GetAxis("Mouse X") * rotationSpeed * Time.deltaTime;
            Quaternion targetRotation = Quaternion.Euler(0, transform.eulerAngles.y + mouseX, 0);
            transform.rotation = Quaternion.Slerp(transform.rotation, targetRotation, rotationSmoothing * Time.deltaTime);
        }
    }

    private void Jump()
    {
        // ����� ������������ �������� ����� �������
        rb.linearVelocity = new Vector3(rb.linearVelocity.x, 0f, rb.linearVelocity.z);
        rb.AddForce(transform.up * jumpForce, ForceMode.Impulse);
    }

    private void ResetJump()
    {
        readyToJump = true;
    }
}
