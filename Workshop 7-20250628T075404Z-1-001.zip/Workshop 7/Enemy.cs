using UnityEngine;
using TMPro;
using UnityEngine.SceneManagement;

public class Enemy : MonoBehaviour
{
    [Header("Destruction Settings")]
    public GameObject cubePiecePrefab;
    public float explodeForce = 500f;
    public float explosionRadius = 5f;

    [Header("Sound Settings")]
    public AudioClip destructionSound;
    [Range(0, 1)] public float soundVolume = 0.8f;

    [Header("Score Settings")]
    [SerializeField] private TextMeshProUGUI scoreText;
    public int scoreValue = 10;

    private void OnCollisionEnter(Collision collision)
    {
        if (collision.gameObject.CompareTag("Bullet"))
        {
            HandleDestruction();
        }
    }

    private void HandleDestruction()
    {
        PlayDestructionSound();
        ExplodeCube();
        AddScore();
        Destroy(gameObject);
    }

    private void PlayDestructionSound()
    {
        if (destructionSound != null)
        {
            AudioSource.PlayClipAtPoint(destructionSound,
                                      transform.position,
                                      soundVolume);
        }
    }

    private void AddScore()
    {
        if (Progress.Instance != null)
        {
            Progress.Instance.PlayerInfo.Score += scoreValue;

            if (scoreText != null)
            {
                scoreText.text = $"Score: {Progress.Instance.PlayerInfo.Score}";
            }

            if (Progress.Instance.PlayerInfo.Score >= 100)
            {
                Progress.Instance.PlayerInfo.Score = 0; // �������� ����
                ReloadLevel();
            }
        }
    }

    private void ExplodeCube()
    {
        if (cubePiecePrefab == null) return;

        for (int x = 0; x < 4; x++)
        {
            for (int y = 0; y < 4; y++)
            {
                for (int z = 0; z < 4; z++)
                {
                    Vector3 position = transform.position + new Vector3(x, y, z) * 0.5f;
                    GameObject piece = Instantiate(cubePiecePrefab, position, Quaternion.identity);

                    if (piece.TryGetComponent<Rigidbody>(out var rb))
                    {
                        rb.AddExplosionForce(explodeForce,
                                           transform.position,
                                           explosionRadius);
                    }
                }
            }
        }
    }

    private void ReloadLevel()
    {
        SceneManager.LoadScene(SceneManager.GetActiveScene().name);
    }
}
