using UnityEngine;
using UnityEngine.UI;
using System.Collections;
using TMPro;

public class CubeGameController : MonoBehaviour
{
    public GameObject[] cubes;      // Массив из 3 кубов
    public Button[] buttons;        // Массив из 3 кнопок
    public TMP_Text resultText;         // Текст для сообщений

    private bool gameActive = true;

    void Start()
    {
        // Назначаем обработчики кнопок
        for (int i = 0; i < buttons.Length; i++)
        {
            int idx = i; // Локальная копия для лямбды
            buttons[i].onClick.AddListener(() => OnCubeButtonClick(idx));
        }

        StartGame();
    }

    void StartGame()
    {
        // Сброс кубов в исходное положение и состояние
        foreach (var cube in cubes)
        {
            cube.transform.position = new Vector3(cube.transform.position.x, 0f, cube.transform.position.z);
            Rigidbody rb = cube.GetComponent<Rigidbody>();
            if (rb == null)
                rb = cube.AddComponent<Rigidbody>();

            rb.isKinematic = true;   // Отключаем физику — кубы висят
            rb.useGravity = true;
            rb.linearVelocity = Vector3.zero;
            rb.angularVelocity = Vector3.zero;
        }

        // Включаем кнопки
        foreach (var btn in buttons)
            btn.interactable = true;

        resultText.text = "Guess the Cube";
        gameActive = true;
    }

    public void OnCubeButtonClick(int index)
    {
        if (!gameActive)
            return;

        gameActive = false;

        // Отключаем кнопки
        foreach (var btn in buttons)
            btn.interactable = false;

        // Безопасный куб — тот, на который кликнули
        DropCubesExcept(index);

        // Показываем победу
        resultText.text = "YOU WIN";

        // Перезапуск через 3 секунды
        StartCoroutine(RestartAfterDelay(3f));
    }

    private void DropCubesExcept(int exceptIndex)
    {
        for (int i = 0; i < cubes.Length; i++)
        {
            Rigidbody rb = cubes[i].GetComponent<Rigidbody>();
            if (i != exceptIndex)
                rb.isKinematic = false; // Включаем физику — кубы падают
            else
                rb.isKinematic = true;  // Безопасный куб висит
        }
    }

    private IEnumerator RestartAfterDelay(float delay)
    {
        yield return new WaitForSeconds(delay);
        StartGame();
    }
}



